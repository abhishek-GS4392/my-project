<?php

namespace app\models;

use Yii;
//use yii\base\Model;
use yii\db\ActiveRecord;

class Comments extends ActiveRecord
{
    public function rules()
    {
        return [
            [['name', 'comment'], 'required'],
        ];
    }
}