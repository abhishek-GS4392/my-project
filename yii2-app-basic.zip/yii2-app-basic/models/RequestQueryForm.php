<?php

namespace app\models;

use Yii;
//use yii\base\Model;
use yii\db\ActiveRecord;

class RequestQueryForm extends ActiveRecord
{
    public $name;
    public $comment;


    public function rules()
    {
        return [
            [['name', 'comment'], 'required'],
        ];
    }
}