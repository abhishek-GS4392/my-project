<?php
use yii\helpers\Html;
?>

<div>
    Admin\userController called<br>
    <?= Html::encode(__FILE__) ?>
</div>