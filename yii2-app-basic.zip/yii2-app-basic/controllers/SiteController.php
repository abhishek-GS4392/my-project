<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\EntryForm;
use app\models\RequestQueryForm;
use app\models\Comments;

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    public function actionAbout()
    {
        return $this->render('about');
    }

    /**
     * Form that does not have database table
     */
    public function actionEntry()
    {
        $model = new EntryForm();

        if($model->load(Yii::$app->request->post()) && $model->validate())
        {
            return $this->render('entry-confirm', ['model' => $model]);
        }
        else
        {
            return $this->render('entry', ['model' => $model]);
        }
    }

    /**
     * Form that has database table
     */
   /* public function actionRequestQuery()
    {
        $model = new RequestQueryForm();

        if($model->load(Yii::$app->request->post()) && $model->validate())
        {
            $model_new = new Comments();

            $postData = Yii::$app->request->post('RequestQueryForm');
            $model_new->name = $postData['name'];
            $model_new->comment = $postData['comment'];
            $model_new->save();
        }

        return $this->render('requestQuery', ['model' => $model]);
    }*/

    public function actionRequestQuery()
    {
        $model = new Comments();

        if($model->load(Yii::$app->request->post()) && $model->validate())
        {
            //$postData = Yii::$app->request->post('Comments');
            $model->save();

            Yii::$app->session->setFlash('success', "Comment has been saved!");;
            return $this->refresh();
        }

        return $this->render('requestQuery', ['model' => $model]);
    }
}
