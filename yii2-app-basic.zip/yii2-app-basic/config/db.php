<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii2_basic',
    'username' => 'root',
    'password' => '123@abc',
    'charset' => 'utf8',
];
